import base64
import datetime
import os
import logging
import uuid

from flask import request
from flask_restful import Resource
from common import utils as ut
from models import config

file_name = os.path.basename(__file__)


class SignUp(Resource):
    """
    To create an user credentials for registering into screen factor
    """

    def post(self):
        conn = False
        try:
            logging.info(f'filename:{file_name}-class:{self.__class__}')
            conn = config.get_ebuy_db_conn()
            if 'False' in str(conn):
                return {"res_status": False, "msg": "Database Connection Failed"}

            logging.info("To create credentials for user.....................")
            request_data = request.get_json()
            cur = conn.cursor()
            validating_password = ut.validatingPassword(request_data['password'])
            if validating_password != 1:
                return {"res_status": False, "msg": str(validating_password)}

            if len(str(request_data['telephone'])) > 10 or len(str(request_data['telephone'])) < 10:
                return {"res_status": False, "msg": 'Please Enter valid telephone'}

            username = request_data['firstname']+request_data['lastname']

            cur.execute(f""" insert into user_master(firstname, lastname, username,password, email,telephone, created_by) 
                             values ('{request_data['firstname']}', '{request_data['lastname']}', 
                             '{username}', '{request_data['password']}','{request_data['email']}', 
                             '{request_data['telephone']}', '{username}') """)
            conn.commit()
            cur.close()
            return {"res_status": True, "status": 200, "msg": 'User Registered Successfully'}

        except Exception as e:
            logging.error("Error occurred in SignUp: " + str(e) + "\n...........................................")
            return {"res_status": False, "msg": str(e)}
        finally:
            if str(conn) != 'False':
                conn.close()


class Login(Resource):
    """
    To validate user and login
    """

    def post(self):
        conn = False
        try:
            logging.info(f'filename:{file_name}-class:{self.__class__}')
            conn = config.get_ebuy_db_conn()
            if 'False' in str(conn):
                return {"res_status": False, "msg": "Database Connection Failed"}

            logging.info("To verify credentials of user.....................")
            request_data = request.get_json()
            email = request_data['email']
            logging.info("user login to Login...............:" + str(email))
            password = request_data['password']
            password = base64.b64decode(password).decode('utf-8')
            session_id = uuid.uuid4()
            time = 15
            session_start_time = datetime.datetime.today().replace(microsecond=0)
            session_end_time = (datetime.datetime.today() + datetime.timedelta(minutes=time)).replace(microsecond=0)
            cur = conn.cursor()

            cur.execute("select password, user_id from user_master where upper(email) = '%s'"%(email.upper()))
            row = cur.fetchone()
            if row is not None:
                db_password = row[0]
                user_id = row[1]
                if password == db_password:
                    logging.info("User credentials are verified .................")
                    response_data = {"res_status": True, "status": 200}
                else:
                    logging.info("Invalid user/pwd.please check your credentials...............")
                    return {"res_status": False, "msg": "Invalid user/pwd.please check your credentials"}
            else:
                return {"res_status": False, "msg": "Invalid user/pwd.please check your credentials"}

            if response_data['res_status'] == True:

                cur.execute("insert into user_login_txn (user_name,session_id,session_start_time,session_end_time) "
                            "values('%s', '%s', '%s','%s')" %
                            (email, session_id, session_start_time, session_end_time))
                conn.commit()
                logging.info("inserted into asda login transaction table.............")
                data = []
                data.append({"user_name": email, "session_id": str(session_id), "user_id": str(user_id), "timeout": time})
                final_data = {"res_status": True, "status": 200, "data": data}
            else:
                logging.info("Invalid user/pwd.please check your credentials...............")
                final_data = {"res_status": False, "msg": "Invalid user/pwd.please check your credentials"}
            return final_data
        except Exception as e:
            logging.error("Error occurred while verifying credentials in Login: " + str(e)
                          + "\n...........................................")
            return {"res_status": False, "msg": str(e)}
        finally:
            if str(conn) != 'False':
                conn.close()
