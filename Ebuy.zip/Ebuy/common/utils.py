import re


def validatingPassword(password):
    if len(password) >= 8:
        if re.search('\W+', password) and re.search('[0-9]+', password):
            if re.search('[A-Z]', password) and re.search('[a-z]+', password):
                if re.search('\s+', password) == None:
                    return 1
                else:
                    return "password should not contain spaces"
            else:
                return "your password is invalid, should contain combination of upper and lower case letters"
        else:
            return "your password is invalid, should contain atleast one special character and  number"
    else:
        return "password is too short, minimum length is 8 characters"