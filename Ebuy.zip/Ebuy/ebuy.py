import datetime
from flask import Flask
from flask_cors import CORS
from flask_restful import Api

from read_properties import properties

app = Flask(__name__)
api = Api(app)
CORS(app)

from resource.user_signup import SignUp
from resource.user_signup import Login

api.add_resource(SignUp, '/ebuy/sign_up')
api.add_resource(Login, '/ebuy/login')

if __name__ == '__main__':
    current_timestamp = datetime.datetime.now()
    date_time = current_timestamp.strftime("%Y-%m-%d_%H-%M-%S")
    app.run(host=properties['db_host'], port=properties['db_port'], debug=False, use_reloader=False)
